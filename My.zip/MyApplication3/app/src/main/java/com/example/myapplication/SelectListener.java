package com.example.myapplication;

import com.example.myapplication.Models.NewsHeadlines;

public interface SelectListener {
    void OnNewsClicked(NewsHeadlines headlines);

}
